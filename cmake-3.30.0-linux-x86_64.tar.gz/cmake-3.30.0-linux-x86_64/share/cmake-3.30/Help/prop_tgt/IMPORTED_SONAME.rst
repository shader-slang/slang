IMPORTED_SONAME
---------------

The ``soname`` of an ``IMPORTED`` target of shared library type.

Set this to the ``soname`` embedded in an imported shared library.  This
is meaningful only on platforms supporting the feature.  Ignored for
non-imported targets.
