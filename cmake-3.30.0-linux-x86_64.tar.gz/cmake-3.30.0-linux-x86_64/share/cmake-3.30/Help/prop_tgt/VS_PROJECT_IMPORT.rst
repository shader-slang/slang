VS_PROJECT_IMPORT
-----------------

.. versionadded:: 3.15

Visual Studio managed project imports

Adds to a generated Visual Studio project one or more semicolon-delimited paths
to .props files needed when building projects from some NuGet packages.
For example, ``my_packages_path/MyPackage.1.0.0/build/MyPackage.props``.
