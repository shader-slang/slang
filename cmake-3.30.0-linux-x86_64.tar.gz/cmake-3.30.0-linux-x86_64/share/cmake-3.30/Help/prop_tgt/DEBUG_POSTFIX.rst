DEBUG_POSTFIX
-------------

See target property :prop_tgt:`<CONFIG>_POSTFIX`.

This property is a special case of the more-general :prop_tgt:`<CONFIG>_POSTFIX`
property for the ``DEBUG`` configuration.
