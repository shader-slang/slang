VS_DOTNET_REFERENCES
--------------------

Visual Studio managed project .NET references

Adds one or more semicolon-delimited .NET references to a generated
Visual Studio project.  For example, "System;System.Windows.Forms".
