extern "C" void VerifyCXX(void)
{
  delete new int;
}
